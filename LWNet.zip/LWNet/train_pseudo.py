import shutil
from tqdm import tqdm
import glob
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset
import random
import cv2
import os
from losses.loss import *
from Network.net import Net as MODEL
from config import args
device = args.gpu


class GetDataset(Dataset):
    def __init__(self, data_path1, data_path2, data_path3):
        self.data_path1 = data_path1
        self.data_path2 = data_path2
        self.data_path3 = data_path3

    def __getitem__(self, index):

        mri = self.data_path1[index]
        oth = self.data_path2[index]
        label = self.data_path3[index]

        mri = cv2.imread(mri, 0)
        oth = cv2.imread(oth, 0)
        label = cv2.imread(label, 0)

        tran = transforms.ToTensor()
        mri = tran(mri)
        oth = tran(oth)
        label = tran(label)
        return mri, oth, label

    def __len__(self):
        return len(self.data_path1)


def train(train_loader, model, optimizer):
    loss_mean = []
    model.to(device)
    model.train()

    for i, (mri, oth, label) in tqdm(enumerate(train_loader), total=len(train_loader)):
        mri = mri.to(device)
        oth = oth.to(device)
        label = label.to(device)

        out = model(mri, oth)
        ssim = SSIM_loss(out, label)
        l1_1 = L1_loss(out, mri)
        l1_2 = L1_loss(out, oth)
        loss = ssim + l1_1 + l1_2

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        loss_mean.append(loss.item())
    epoch_loss = sum(loss_mean) / len(loss_mean)
    return epoch_loss


def setup_seed(seed=302):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def main():
    setup_seed()
    model = MODEL()
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    for i in range(10):
        print('第{}轮迭代:'.format(i + 1))
        if i > 0:
            model.load_state_dict(torch.load('model_save_pseudo1/model_10.pth'))

        data_path1 = 'dataset/train_label/MRI/'
        data_path2 = 'dataset/train_label/Oth/'
        data_path3 = 'dataset/train_label/Label/'
        data_path1 = glob.glob(data_path1 + '*.png')
        data_path2 = glob.glob(data_path2 + '*.png')
        data_path3 = glob.glob(data_path3 + '*.png')
        dataset = GetDataset(data_path1=data_path1, data_path2=data_path2, data_path3=data_path3)
        train_loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, drop_last=True, num_workers=1,
                                  pin_memory=True)
        loss_plt = []
        for epoch in range(args.epochs):
            print('Epoch [%d/%d]' % (epoch + 1, args.epochs))
            epoch_loss = train(train_loader, model, optimizer)
            print('Loss:%.5f' % epoch_loss)

            loss_plt.append(epoch_loss)
            strain_path = 'model_save_pseudo1/loss.txt'
            loss_file = 'Epoch--' + str(epoch + 1) + '\t' + 'Loss:' + str(epoch_loss)
            with open(strain_path, 'a') as f:
                f.write(loss_file + '\r\n')

            if (epoch + 1) % 1 == 0:
                torch.save(model.state_dict(), 'model_save_pseudo1/model_{}.pth'.format(epoch + 1))
        print('第{}轮迭代完成.'.format(i + 1))
        print('选择伪标签:')
        path = 'dataset/train_crop/MRI/'
        files = os.listdir(path)
        model.load_state_dict(torch.load('model_save_pseudo1/model_10.pth'))
        model.eval()
        for file in files:
            with torch.no_grad():
                path1 = os.path.join('dataset/train_crop/MRI', file)
                path2 = os.path.join('dataset/train_crop/SPECT', file)
                mri = cv2.imread(path1, 0)
                oth = cv2.imread(path2, 0)

                tran = transforms.ToTensor()

                mri = tran(mri)
                oth = tran(oth)

                mri = mri.to(device)
                oth = oth.to(device)

                mri = mri.unsqueeze(0)
                oth = oth.unsqueeze(0)

                out = model(mri, oth)
                if (SSIM(out, mri) + SSIM(out, oth)) > 1.10:
                    shutil.move(path1, 'dataset/train_label/MRI/')
                    shutil.move(path2, 'dataset/train_label/Oth/')
                    out = ((out[0][0]).detach().cpu().numpy() * 255).astype(np.uint8)
                    cv2.imwrite('dataset/train_label/Label/{}.png'.format(file.split('.')[0]), out)
                    print(file.split('.')[0])
            del mri, oth, out
            torch.cuda.empty_cache()


if __name__ == '__main__':
    main()
